# 📈 Time Series Analysis - PPGE/UFPB

Repositório central para as resoluções das atividades práticas da disciplina de **Econometria de Séries Temporais** ministrada pelo professor Cássio Besarria. O foco do projeto é o desenvolvimento de rotinas robustas para análise econométrica e processamento de dados financeiros e de commodities.

## 🗂️ Organização do Projeto

O repositório é estruturado de forma modular por listas de exercícios. Cada diretório é autocontido:

* **scripts/**: Contém as rotinas de coleta de dados (Python) e os scripts de processamento estatístico e modelagem (R).
* **outputs/**: Diretório gerado automaticamente pelos scripts para armazenar tabelas (`.csv`, `.txt`) e visualizações gráficas (`.png`). *Nota: Este diretório está no .gitignore.*
* **data/**: Armazena os datasets brutos extraídos. *Nota: Este diretório está no .gitignore.*
* **resolucao.md**: Relatório técnico final contendo a fundamentação teórica, análise dos outputs e interpretação econômica dos resultados.

> **Nota de Isenção:** Os resultados e análises contidos neste repositório referem-se estritamente à base de dados selecionada para fins de estudo pessoal. O conteúdo está sujeito a erros de interpretação ou execução de minha autoria, não devendo ser utilizado como fonte oficial ou gabarito para a resolução das atividades da disciplina.

## 🛠️ Stack Tecnológica

* **Linguagens**: R (Análise Estatística e Econometria) e Python (Extração de dados/ETL).
* **Ambiente**: Desenvolvimento via scripts puros e execução em IDE (Positron/VS Code).
* **Gestão de Dados**: Coleta automatizada via APIs financeiras (Yahoo Finance)
## 🚀 Como Executar

Para reproduzir os resultados de uma lista específica:

1.  Navegue até a pasta do exercício: `cd lista_XX/scripts/`
2.  Execute o script de coleta: `python get_data.py`
3.  Execute os scripts de análise em R seguindo a ordem numérica: `01_...R`, `02_...R`, etc.

Os diretórios de `data` e `outputs` serão criados automaticamente caso não existam, garantindo a reprodutibilidade do ambiente.

## ✉️ Contact Me

Fique à vontade para entrar em contato para discussões acadêmicas ou colaborações em projetos de pesquisa:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andrefbrandao/)
[![Email](https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:brandaoandrefilipe@gmail.com)

---
**André Filipe Brandão** - *Doutorando em Economia Aplicada - PPGE/UFPB*
---

