# q2_analise_estatistica.R
library(fBasics)
library(DescTools)

# 1. Ajuste Dinâmico do Diretório (Garante execução correta a partir da pasta scripts)
if (interactive()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  setwd("..") # Sobe para a pasta 'lista_01'
}

# 2. Configuração do diretório de saída
path_out <- "outputs/"
if(!dir.exists(path_out)) dir.create(path_out, recursive = TRUE)

# 3. Carga e Log (Estabilização da variância)
# Busca o arquivo na pasta data/ vizinha
df <- read.csv("data/commodity_data.csv")
serie_log <- log(df$preco)

# 4. Cálculos Estatísticos
stats <- basicStats(serie_log)
q_25 <- quantile(serie_log, 0.25, na.rm = TRUE)
q_75 <- quantile(serie_log, 0.75, na.rm = TRUE)
moda_val <- as.numeric(Mode(serie_log, na.rm = TRUE)[1])

# 5. Criando a Tabela Consolidada
tabela_stats <- data.frame(
  Medida = c("Média", "Mediana", "Moda", "Variância", "Desvio-Padrão", 
             "Assimetria", "Curtose", "Percentil 25%", "Percentil 75%"),
  Valor = c(
    stats["Mean",], stats["Median",], moda_val,
    stats["Variance",], stats["Stdev",], stats["Skewness",],
    stats["Kurtosis",], q_25, q_75
  )
)

# 6. Exportação da Tabela (.csv) para outputs
write.csv(tabela_stats, paste0(path_out, "tabela_q2.csv"), row.names = FALSE)

# Exibe no console para conferência rápida
print(tabela_stats, row.names = FALSE)

# 7. Gráfico (.png) para outputs
png(paste0(path_out, "q2_visualizacao.png"), width = 900, height = 450)
par(mfrow = c(1, 2))
hist(serie_log, main="Histograma da Série", col="lightblue", border="white", xlab="Log-Preço")
boxplot(serie_log, main="Box-plot e Outliers", col="lightgreen", ylab="Log-Preço")
dev.off()

cat("\nExecutado em:", getwd(), "\nArquivos salvos em:", path_out, "\n")