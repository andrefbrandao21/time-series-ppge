# q4_outliers.R
install.packages('outliers')

library(outliers)
library(forecast)

# 1. Ajuste Dinâmico do Diretório
if (interactive()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  setwd("..") # Sobe para a pasta 'lista_01'
}

# 2. Configuração de caminhos e carga
path_out <- "outputs/"
if(!dir.exists(path_out)) dir.create(path_out, recursive = TRUE)

df <- read.csv("data/commodity_data.csv")
serie_log <- log(df$preco)

# 3. Identificação de Outliers

# Método A: Teste de Grubbs (Identifica o valor mais extremo e testa se é outlier)
# Útil para detectar um outlier por vez.
test_grubbs <- grubbs.test(serie_log)

# Método B: Scores Z (Identifica quão longe cada ponto está da média em desvios-padrão)
# Pontos com score > 3 ou < -3 são geralmente considerados outliers
scores_z <- scores(serie_log, type = "z")
outliers_z <- serie_log[abs(scores_z) > 3]

# Método C: Resíduos da Decomposição (Foco em choque estrutural)
dec <- decompose(ts(serie_log, frequency = 252), type = "multiplicative")
residuos <- na.omit(dec$random)
outliers_residuos <- residuos[abs(scores(residuos, type = "z")) > 3]

# 4. Exportação do Relatório Técnico
sink(paste0(path_out, "relatorio_outliers_q4.txt"))
cat("=== ANÁLISE TÉCNICA DE OUTLIERS ===\n\n")
cat("1. RESULTADO DO TESTE DE GRUBBS:\n")
print(test_grubbs)
cat("\n2. PONTOS IDENTIFICADOS VIA Z-SCORE (> 3 SD):\n")
print(outliers_z)
cat("\n3. CHOQUES NOS RESÍDUOS (APÓS DECOMPOSIÇÃO):\n")
print(outliers_residuos)
sink()

# 5. Gráfico de Identificação
png(paste0(path_out, "q4_outliers_plot.png"), width = 1000, height = 600)
par(mfrow = c(2, 1))

# Plot da Série com destaque para Z-Scores altos
plot(serie_log, type = "l", main = "Série Log: Destaque Z-Score > 3", col = "gray")
points(which(abs(scores_z) > 3), serie_log[abs(scores_z) > 3], col = "red", pch = 19)

# Plot dos Resíduos com destaque para choques
plot(residuos, type = "l", main = "Resíduos (Irregular): Destaque para Choques", col = "darkblue")
abline(h = c(3, -3), col = "red", lty = 2)

dev.off()

cat("\nExecutado em:", getwd(), "\nRelatório e gráficos salvos em:", path_out, "\n")
