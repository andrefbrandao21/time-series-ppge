import yfinance as yf
import pandas as pd
import os

def get_data():
    # Caminho relativo para a pasta data
    data_dir = '../data'
    
    # Cria o diretório caso não exista (recursivo)
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
        print(f"Diretório '{data_dir}' criado com sucesso.")

    # Usando o Milho de Chicago (ZC=F) que é estável e tem forte sazonalidade
    ticker = "ZC=F" 
    print(f"Baixando dados para {ticker}...")
    
    # Download dos dados
    data = yf.download(ticker, start="2015-01-01", auto_adjust=True)
    
    if not data.empty:
        # Garante que pegamos apenas a coluna de fechamento, mesmo com MultiIndex
        if isinstance(data.columns, pd.MultiIndex):
            # Acessando o nível do Ticker no MultiIndex do yfinance
            df = data['Close'][ticker].reset_index()
        else:
            df = data['Close'].reset_index()
            
        df.columns = ['data', 'preco']
        
        # Salvando no caminho correto
        output_path = os.path.join(data_dir, 'commodity_data.csv')
        df.to_csv(output_path, index=False)
        print(f"Sucesso! Arquivo '{output_path}' criado.")
    else:
        print("Falha crítica: O Yahoo Finance não retornou dados.")

if __name__ == "__main__":
    get_data()