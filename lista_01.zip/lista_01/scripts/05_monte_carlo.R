# q5_monte_carlo.R
library(forecast)

# 1. Ajuste Dinâmico do Diretório
if (interactive()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  setwd("..") # Sobe para a pasta 'lista_01'
}

# 2. Configuração de caminhos
path_out <- "outputs/"
if(!dir.exists(path_out)) dir.create(path_out, recursive = TRUE)

# 3. Simulação de Monte Carlo (n = 200)
set.seed(42)
n <- 200
t <- 1:n
erro <- rnorm(n, mean = 0, sd = 2)

# Gerando as 3 séries sintéticas
s1_ruido   <- ts(10 + erro, frequency = 12)
s2_trend   <- ts(10 + 0.5 * t + erro, frequency = 12)
s3_seasonal <- ts(10 + 5 * sin(2 * pi * t / 12) + erro, frequency = 12)

# 4. Aplicação das Técnicas de Suavização
# SES para a série sem padrão
fit1 <- ses(s1_ruido, h = 12) 

# Holt para a série com tendência
fit2 <- holt(s2_trend, h = 12)

# Holt-Winters para a série com sazonalidade (aditivo)
fit3 <- hw(s3_seasonal, seasonal = "additive", h = 12)

# 5. Visualização e Exportação
png(paste0(path_out, "q5_suavizacao_montecarlo.png"), width = 1000, height = 900, res = 100)
par(mfrow = c(3, 1), mar = c(3, 4, 2, 1))

plot(fit1, main = "1. Suavização Exponencial Simples (SES) - Ruído", col = "black")
lines(fitted(fit1), col = "red", lwd = 2)

plot(fit2, main = "2. Método de Holt - Tendência Linear", col = "black")
lines(fitted(fit2), col = "blue", lwd = 2)

plot(fit3, main = "3. Método de Holt-Winters - Sazonalidade", col = "black")
lines(fitted(fit3), col = "darkgreen", lwd = 2)

dev.off()

cat("\nSimulação e Suavização concluídas.\nGráfico salvo em:", path_out, "\n")