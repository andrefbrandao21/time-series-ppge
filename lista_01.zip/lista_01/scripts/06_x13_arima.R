# q6_x13_adjustment.R
library(seasonal)
library(x13binary)
library(forecast)

# 1. Ajuste Dinâmico do Diretório
if (interactive()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  setwd("..") 
}

# 2. Configuração de caminhos
path_out <- "outputs/"
if(!dir.exists(path_out)) dir.create(path_out, recursive = TRUE)

# 3. Carga e Preparação (X-13 exige frequência mensal ou trimestral)
df <- read.csv("data/commodity_data.csv")
# Convertendo para mensal para o X-13 (média do mês)
df$data <- as.Date(df$data)
df_mensal <- aggregate(preco ~ format(data, "%Y-%m"), data = df, FUN = mean)
ts_mensal <- ts(df_mensal$preco, start = c(2015, 1), frequency = 12)

# 4. Aplicação do X-13ARIMA-SEATS
# O comando 'seas' faz o ajuste automático (seleção de modelo ARIMA + Sazonalidade)
fit_x13 <- seas(ts_mensal)

# Extraindo a série ajustada sazonalmente (Seasonally Adjusted)
serie_ajustada <- final(fit_x13)

# 5. Visualização e Exportação
png(paste0(path_out, "q6_x13_adjustment.png"), width = 1000, height = 600, res = 100)

plot(ts_mensal, col = "gray", lwd = 1, main = "Milho: Original vs Ajuste Sazonal (X-13ARIMA-SEATS)",
     ylab = "Preço", xlab = "Ano")
lines(serie_ajustada, col = "red", lwd = 2)
legend("topleft", legend = c("Original (Com Sazonalidade)", "Ajustada (Sem Sazonalidade)"),
       col = c("gray", "red"), lty = 1, lwd = c(1, 2))

dev.off()

# Salva o sumário do modelo para o relatório
sink(paste0(path_out, "relatorio_x13_q6.txt"))
summary(fit_x13)
sink()

cat("\nAnálise X-13 concluída.\nRelatório salvo em:", path_out, "\n")