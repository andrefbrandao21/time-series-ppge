# q1_decomposicao.R
library(forecast)

# 1. Ajuste Dinâmico do Diretório (Pega a pasta onde o script está e sobe um nível)
# Isso garante que ele ache 'data' e 'outputs' dentro de 'lista_01'
if (interactive()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) # Se estiver no IDE
  setwd("..") # Sobe para a pasta 'lista_01'
}

# 2. Configuração de diretórios
path_out <- "outputs/"
if(!dir.exists(path_out)) dir.create(path_out, recursive = TRUE)

# 3. Carregar dados
df <- read.csv("data/commodity_data.csv")
ts_dados <- ts(df$preco, frequency = 252)

# 4. Decomposição Multiplicativa
dec <- decompose(ts_dados, type = "multiplicative")

# 5. Isolar TENDÊNCIA PURA e CICLO
tempo <- 1:length(ts_dados)
modelo_linear <- lm(as.numeric(ts_dados) ~ tempo)
tendencia_pura <- ts(predict(modelo_linear), frequency = 252)
ciclo_puro <- dec$trend / tendencia_pura

# 6. Salvar Visualização
png(paste0(path_out, "q1_decomposicao.png"), width = 1000, height = 800, res = 100)
par(mfrow = c(4, 1), mar = c(3, 4, 2, 1))
plot(tendencia_pura, main = "1. Tendência (Direção Linear)", col = "red", lwd = 2)
plot(ciclo_puro, main = "2. Ciclo (Oscilações de Médio Prazo)", col = "blue")
plot(dec$seasonal, main = "3. Sazonalidade (Padrão Anual Fixo)", col = "darkgreen")
plot(dec$random, main = "4. Aleatório (Ruído/Irregular)", col = "gray")
dev.off()

cat("Executado em:", getwd(), "\nGráfico salvo em:", path_out, "\n")
