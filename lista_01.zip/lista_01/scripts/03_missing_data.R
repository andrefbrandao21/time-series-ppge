# q3_missing_data.R
library(imputeTS)
library(mice)

# 1. Ajuste Dinâmico do Diretório
if (interactive()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  setwd("..") # Sobe para a pasta 'lista_01'
}

# 2. Configuração de caminhos e carga
path_out <- "outputs/"
if(!dir.exists(path_out)) dir.create(path_out, recursive = TRUE)

# Busca os dados na pasta data/
df <- read.csv("data/commodity_data.csv")
serie_original <- log(df$preco)
n <- length(serie_original)

# 3. Eliminação Aleatória de 10%
set.seed(123)
indices_missing <- sample(1:n, size = round(0.10 * n))
serie_gap <- serie_original
serie_gap[indices_missing] <- NA

# --- MÉTODOS DE ESTIMAÇÃO ---

# A. Média e Mediana (Estatísticas Simples)
est_media   <- na_mean(serie_gap, option = "mean")
est_mediana <- na_mean(serie_gap, option = "median")

# B. Interpolação Linear e Splines (Geométricos)
est_linear <- na_interpolation(serie_gap, option = "linear")
est_spline <- na_interpolation(serie_gap, option = "spline")

# C. Técnica Bayesiana (MICE - PMM)
# Contexto com lag para o modelo Bayesiano
df_mice   <- data.frame(y = serie_gap, y_lag = c(NA, head(serie_gap, -1)))
imp_bayes <- mice(df_mice, method = "pmm", m = 5, printFlag = FALSE) 
est_bayes <- complete(imp_bayes)$y

# 4. Cálculo do Erro (RMSE)
calc_rmse <- function(orig, estim, ind) sqrt(mean((orig[ind] - estim[ind])^2))

res_rmse <- c(
  Média = calc_rmse(serie_original, est_media, indices_missing),
  Mediana = calc_rmse(serie_original, est_mediana, indices_missing),
  Linear = calc_rmse(serie_original, est_linear, indices_missing),
  Spline = calc_rmse(serie_original, est_spline, indices_missing),
  Bayesiano = calc_rmse(serie_original, est_bayes, indices_missing)
)

# 5. Tabela de Comparação Final
tabela_q3 <- data.frame(
  Metodo = names(res_rmse),
  RMSE = as.numeric(res_rmse)
)
tabela_q3 <- tabela_q3[order(tabela_q3$RMSE), ] # Ordena do melhor para o pior

# Exportação da tabela
write.csv(tabela_q3, paste0(path_out, "tabela_q3_comparativo.csv"), row.names = FALSE)
print(tabela_q3)

# 6. Gráfico de Visualização (Amostra de 100 obs para clareza visual)
png(paste0(path_out, "q3_visualizacao_comparativa.png"), width = 1000, height = 600)
plot(serie_original[1:100], type = "l", lwd = 2, main = "Comparativo de Imputação (Amostra 100 obs)",
     xlab = "Tempo", ylab = "Log-Preço")
lines(est_linear[1:100], col = "red", lty = 2)
lines(est_bayes[1:100], col = "blue", lty = 2)
legend("topright", legend=c("Original", "Linear", "Bayesiano"), 
       col=c("black", "red", "blue"), lty=c(1,2,2), lwd=c(2,1,1))
dev.off()

cat("\nExecutado em:", getwd(), "\nArquivos salvos em:", path_out, "\n")